﻿using System.ComponentModel.DataAnnotations.Schema;

namespace IFeelGoodSalon.RepositoryPattern
{
    public enum ObjectState
    {
        Unchanged,
        Added,
        Modified,
        Deleted
    }

    public interface IObjectState
    {
        [NotMapped]
        ObjectState ObjectState { get; set; }
    }
}
